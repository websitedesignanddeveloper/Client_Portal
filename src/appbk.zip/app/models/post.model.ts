export class Post {
	constructor(){
		this.id = '';
		this.title = '';
		this.description = '';
	}
	public id;
	public title;
	public description;
}